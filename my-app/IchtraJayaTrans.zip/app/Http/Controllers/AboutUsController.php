<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutUsController extends Controller
{
    public function aboutus()
    {
        return view('homepage.aboutus');
    }
}
