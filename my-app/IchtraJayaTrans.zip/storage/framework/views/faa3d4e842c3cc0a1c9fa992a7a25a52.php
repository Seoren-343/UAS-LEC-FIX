<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>
    <link href="<?php echo e(asset('css/Contact.css')); ?>" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <a class="navbar-brand" href="#">Contacts</a>
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('founders')); ?>">Founder</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('category-bus')); ?>">Category Bus</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('galleries')); ?>">Gallery</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('aboutUs')); ?>">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('contacts')); ?>">Contact</a></li>
        </ul>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->isAdmin()): ?>
                <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="form-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </nav>
    <div class="container">
        <h1>Contacts</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Office Number</th>
                    <th>Fax</th>
                    <th>Location</th>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->isAdmin()): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contact->id); ?></td>
                        <td><?php echo e($contact->office_num); ?></td>
                        <td><?php echo e($contact->fax); ?></td>
                        <td><?php echo e($contact->location); ?></td>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->isAdmin()): ?>
                                <td>
                                    <a href="<?php echo e(route('contactFol.contactedit', $contact->id)); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this contact?')">Delete</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->isAdmin()): ?>
                <a href="<?php echo e(route('contactFol.contactcreate')); ?>" class="btn btn-success">Create Contact</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-column">
                <h3>ADDRESS</h3>
                <p>Jl. Moh. Toha No.30B, Pamulang Tim., Kec. Pamulang</p>
                <p>Kota Tangerang Selatan, Banten 15412</p>
            </div>
            <div class="footer-column">
                <h3>PHONE</h3>
                <p>Contact Office</p>
                <p>0813-1127-7272</p>
                <p>021-7496562</p>
                <p>021-7490311</p>
                <p>Fax: 021-7419242</p>
            </div>
            <div class="footer-column">
                <h3>EMAIL</h3>
                <p>bisichtrahaya@gmail.com</p>
            </div>
            <div class="footer-column">
                <h3>COMPANY</h3>
                <a href="<?php echo e(url('founders')); ?>">Founder</a>
                <a href="<?php echo e(url('galleries')); ?>">Gallery</a>
                <a href="<?php echo e(url('aboutUs')); ?>">About Us</a>
                <a href="<?php echo e(url('contacts')); ?>">Contact</a>
            </div>
        </div>
    </footer>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\UAS-LEC-FIX\my-app\resources\views/contactFol/contacts.blade.php ENDPATH**/ ?>