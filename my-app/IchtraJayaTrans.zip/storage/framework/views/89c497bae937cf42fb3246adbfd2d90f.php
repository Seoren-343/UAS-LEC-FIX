<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Website</title>
    <link href="<?php echo e(asset('css/Home.css')); ?>" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('founders')); ?>">Founder</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('category-bus')); ?>">Category Bus</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('galleries')); ?>">Gallery</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('aboutUs')); ?>">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('contacts')); ?>">Contact</a></li>
        </ul>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->isAdmin()): ?>
                <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="form-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </nav>
    <div class="container">
        <div class="maincontent">
            <h1>Welcome to Our Website</h1>
        </div>
    </div>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-column">
                <h3>ADDRESS</h3>
                <p>Jalan Cipayung Raya, Cipayung, Jakarta Timur</p>
                <p>13840 (Depan SMA 4 PGRI)</p>
            </div>
            <div class="footer-column">
                <h3>PHONE</h3>
                <p>Contact Office</p>
                <p>0813-1127-7272</p>
                <p>021-7496562</p>
                <p>021-7490311</p>
                <p>Fax: 021-7419242</p>
            </div>
            <div class="footer-column">
                <h3>EMAIL</h3>
                <p>bisichtrahaya@gmail.com</p>
            </div>
            <div class="footer-column">
                <h3>COMPANY</h3>
                <a href="<?php echo e(url('founders')); ?>">Founder</a>
                <a href="<?php echo e(url('galleries')); ?>">Gallery</a>
                <a href="<?php echo e(url('aboutUs')); ?>">About Us</a>
                <a href="<?php echo e(url('contacts')); ?>">Contact</a>
            </div>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\UAS-LEC-FIX\my-app\resources\views/homepage/index.blade.php ENDPATH**/ ?>