<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <h1>Admin Login</h1>
        <form action="<?php echo e(route('admin.login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit">Login</button>
            <?php if($errors->any()): ?>
                <div class="error"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\UAS-LEC-FIX\my-app\resources\views/auth/login.blade.php ENDPATH**/ ?>