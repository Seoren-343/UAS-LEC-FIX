<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link href="<?php echo e(asset('css/Gallery.css')); ?>" rel="stylesheet">
</head>
<body>
    <nav class="navbar">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('founders')); ?>">Founder</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('category-bus')); ?>">Category Bus</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('galleries')); ?>">Gallery</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('aboutUs')); ?>">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('contacts')); ?>">Contact</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>Gallery</h1>
        <div class="image-gallery">
            <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gallery-item">
                    <img src="<?php echo e(asset($bus->bus_picture)); ?>" alt="<?php echo e($bus->bus_type); ?>" class="img-thumbnail">
                    <?php $__currentLoopData = $bus->additionalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($image->image_path)); ?>" alt="<?php echo e($bus->bus_type); ?>" class="img-thumbnail">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-column">
                <h3>ADDRESS</h3>
                <p>Jalan Cipayung Raya, Cipayung, Jakarta Timur</p>
                <p>13840 (Depan SMA 4 PGRI)</p>
            </div>
            <div class="footer-column">
                <h3>PHONE</h3>
                <p>Contact Office</p>
                <p>0813-1127-7272</p>
                <p>021-7496562</p>
                <p>021-7490311</p>
                <p>Fax: 021-7419242</p>
            </div>
            <div class="footer-column">
                <h3>EMAIL</h3>
                <p>bisichtrahaya@gmail.com</p>
            </div>
            <div class="footer-column">
                <h3>COMPANY</h3>
                <a href="<?php echo e(url('founders')); ?>">Founder</a>
                <a href="<?php echo e(url('galleries')); ?>">Gallery</a>
                <a href="<?php echo e(url('aboutUs')); ?>">About Us</a>
                <a href="<?php echo e(url('contacts')); ?>">Contact</a>
            </div>
        </div>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS-LEC-FIX\my-app\resources\views/homepage/gallery.blade.php ENDPATH**/ ?>